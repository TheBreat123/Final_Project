import { createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-auth.js";
import { doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/9.22.2/firebase-firestore.js";
import { auth, db } from "./API.js";

function toggleOtherMajor() {
  const majorSelect = document.getElementById("major");
  const otherMajorGroup = document.getElementById("otherMajorGroup");
  otherMajorGroup.style.display = majorSelect.value === "other" ? "block" : "none";
}

document.addEventListener('DOMContentLoaded', () => {
  const signupForm = document.querySelector('.signup-form');

  signupForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = signupForm.email.value;
    const password = signupForm.password.value;
    const majorValue = signupForm.major.value === "other" ? signupForm.otherMajor.value : signupForm.major.value;

    try {
      // Create user in Firebase Authontication
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Save extra info in Firestore
      await setDoc(doc(db, "users", user.uid), {
        firstName: signupForm.firstName.value,
        lastName: signupForm.lastName.value,
        birthday: signupForm.birthday.value,
        phone: signupForm.phone.value,
        address: signupForm.address.value,
        GPA: signupForm.GPA.value,
        username: signupForm.username.value,
        school: signupForm.school.value,
        gender: signupForm.gender.value,
        ethnicity: signupForm.ethnicity.value,
        major: majorValue,
        email: email,
        createdAt: serverTimestamp()
      });

      alert("Account created successfully!");
      window.location.href = "sign_up.html"; // Go to login
    } catch (error) {
      alert(`Error: ${error.message}`);
    }
  });
});
