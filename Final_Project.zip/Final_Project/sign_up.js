document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.querySelector('.login-form');

  loginForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const email = loginForm.email.value;
    const password = loginForm.password.value;

    auth.signInWithEmailAndPassword(email, password)
      .then(userCredential => {
        // Login successful , redirect to student dashboard
        window.location.href = "student.html";
      })
      .catch(error => {
        let errorMessage = "Login failed.";
        
        if (error.code === "auth/user-not-found") {
          errorMessage = "No account found with that email.";
        } else if (error.code === "auth/wrong-password") {
          errorMessage = "Incorrect password. Please try again.";
        } else if (error.code === "auth/invalid-email") {
          errorMessage = "Invalid email format.";
        }

        alert(errorMessage);
      });
  });
});