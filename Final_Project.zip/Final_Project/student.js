// student.js — display logged-in student's info
document.addEventListener('DOMContentLoaded', () => {
  // DOM elements
  const userNameEl    = document.getElementById('userName');
  const userEmailEl   = document.getElementById('userEmail');
  const userSchoolEl  = document.getElementById('userSchool');
  const userMajorEl   = document.getElementById('userMajor');
  const scholarshipEl = document.getElementById('scholarshipList');
  const logoutBtn     = document.getElementById('logoutBtn');

  // Wait for Firebase auth state
  auth.onAuthStateChanged(async (user) => {
    if (!user) {
      console.warn('No signed-in user — redirecting to login.');
      window.location.href = 'sign_up.html';
      return;
    }

    try {
      // Get the user's Firestore profile
      const docSnap = await db.collection('users').doc(user.uid).get();

      if (docSnap.exists) {
        const data = docSnap.data();

        userNameEl.textContent   = `${data.firstName || ''} ${data.lastName || ''}`.trim() || 'Student';
        userEmailEl.textContent  = data.email || user.email || 'N/A';
        userSchoolEl.textContent = data.school || 'N/A';
        userMajorEl.textContent  = data.major || 'N/A';

        // (Optional) Here you could query scholarships based on the student's info
      } else {
        console.warn(`No Firestore profile found for user ${user.uid}`);
        userNameEl.textContent   = user.displayName || 'Student';
        userEmailEl.textContent  = user.email || 'N/A';
        userSchoolEl.textContent = 'N/A';
        userMajorEl.textContent  = 'N/A';
      }
    } catch (err) {
      console.error('Error fetching student profile:', err);
    }
  });

  // Logout button
  logoutBtn.addEventListener('click', () => {
    auth.signOut()
      .then(() => { window.location.href = 'sign_up.html'; })
      .catch(err => console.error('Error signing out:', err));
  });
});
