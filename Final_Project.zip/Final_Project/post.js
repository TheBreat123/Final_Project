document.getElementById('postScholarshipForm').addEventListener('submit', async function(e) {
  e.preventDefault();

  const statusMessage = document.getElementById("statusMessage");
  statusMessage.textContent = "Posting scholarship...";
  statusMessage.style.color = "blue";

  try {
    // Check auth and db exist
    if (typeof auth === "undefined" || typeof db === "undefined") {
      throw new Error("Firebase auth or Firestore not initialized!");
    }

    const user = auth.currentUser;
    if (!user) {
      statusMessage.textContent = "⚠ You must be logged in to post a scholarship.";
      statusMessage.style.color = "orange";
      return;
    }

    // Gather inputs
    const title = document.getElementById("title")?.value;
    const organization = document.getElementById("organization")?.value;
    const amountRaw = document.getElementById("amount")?.value;
    const deadline = document.getElementById("deadline")?.value;
    const eligibility = document.getElementById("eligibility")?.value;
    const requirements = document.getElementById("requirements")?.value;
    const url = document.getElementById("url")?.value;
    const contactEmail = document.getElementById("contactEmail")?.value;

    // Log all raw input values without trimming
    console.log({
      title,
      organization,
      amountRaw,
      deadline,
      eligibility,
      requirements,
      url,
      contactEmail
    });

    // Now trim and validate fields
    const titleTrim = title?.trim();
    const organizationTrim = organization?.trim();
    const amount = Number(amountRaw);
    const deadlineTrim = deadline?.trim();
    const eligibilityTrim = eligibility?.trim();
    const requirementsTrim = requirements?.trim();
    const urlTrim = url?.trim();
    const contactEmailTrim = contactEmail?.trim();

    if (!titleTrim) throw new Error("Title is required.");
    if (!organizationTrim) throw new Error("Organization is required.");
    if (isNaN(amount) || amount <= 0) throw new Error("Amount must be a positive number.");
    if (!deadlineTrim) throw new Error("Deadline is required.");
    if (!eligibilityTrim) throw new Error("Eligibility is required.");
    if (!requirementsTrim) throw new Error("Requirements are required.");
    if (!urlTrim) throw new Error("URL is required.");
    if (!contactEmailTrim) throw new Error("Contact email is required.");

    // Simple email and URL validations
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(contactEmailTrim)) throw new Error("Contact email is invalid.");
    try {
      new URL(urlTrim);
    } catch {
      throw new Error("URL is invalid.");
    }

    const scholarshipData = {
      title: titleTrim,
      organization: organizationTrim,
      amount,
      deadline: deadlineTrim,
      eligibility: eligibilityTrim,
      requirements: requirementsTrim,
      url: urlTrim,
      contactEmail: contactEmailTrim,
      postedBy: user.uid,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    };

    console.log("Submitting scholarship data:", scholarshipData);

    await db.collection("scholarships").add(scholarshipData);

    statusMessage.textContent = "Scholarship successfully posted!";
    statusMessage.style.color = "green";
    this.reset();

  } catch (error) {
    console.error("Error posting scholarship:", error);
    statusMessage.textContent = `Failed to post scholarship: ${error.message}`;
    statusMessage.style.color = "red";
  }
});
