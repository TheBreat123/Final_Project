// API2.js

const firebaseConfig = {
  apiKey: "AIzaSyC6BU7KbUpVzlS01O3L1CoiINgMUxE-Bi8",
  authDomain: "campuskey-c12c4.firebaseapp.com",
  projectId: "campuskey-c12c4",
  storageBucket: "campuskey-c12c4.appspot.com",
  messagingSenderId: "913597848661",
  appId: "1:913597848661:web:f530930c86af00f4a608dc",
  measurementId: "G-T51D5P5E7G"
};

// Starts Firebase app
firebase.initializeApp(firebaseConfig);

window.auth = firebase.auth();
window.db = firebase.firestore();

